# Obtain skill
